<?php
// ============================================================
// actions/fetch.php  –  GET data endpoints (JSON)
// ============================================================

require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');
$action = $_GET['action'] ?? '';

switch ($action) {

    // ── All events (upcoming first) ───────────────────────────
    case 'events':
        $rows = getDB()
            ->query('SELECT id, name, event_type, event_date, event_time, venue, description
                     FROM events ORDER BY event_date ASC')
            ->fetchAll();
        echo json_encode(['success' => true, 'data' => $rows]);
        break;

    // ── All parents + their students (grouped) ───────────────
    case 'parents':
        $rows = getDB()->query(
            'SELECT p.id, p.first_name, p.last_name, p.phone, p.email,
                    p.relationship, p.photo_path, p.registered_at,
                    s.id AS s_id, s.first_name AS s_first, s.last_name AS s_last,
                    s.student_class, s.student_id_no, s.gender, s.photo_path AS s_photo,
                    COALESCE(s.source_student_id, s.id) AS canonical_student_id
             FROM parents p
             LEFT JOIN students s ON s.parent_id = p.id
             ORDER BY p.registered_at DESC, s.id ASC'
        )->fetchAll();

        $parents = [];
        foreach ($rows as $row) {
            $pid = $row['id'];
            if (!isset($parents[$pid])) {
                $parents[$pid] = [
                    'id'           => $row['id'],
                    'first_name'   => $row['first_name'],
                    'last_name'    => $row['last_name'],
                    'phone'        => $row['phone'],
                    'email'        => $row['email'],
                    'relationship' => $row['relationship'],
                    'photo_path'   => $row['photo_path'],
                    'registered_at'=> $row['registered_at'],
                    's_first'      => $row['s_first'],
                    's_last'       => $row['s_last'],
                    'student_class'=> $row['student_class'],
                    'student_id_no'=> $row['student_id_no'],
                    's_photo'      => $row['s_photo'],
                    'wards'        => [],
                ];
            }
            if ($row['s_id']) {
                $parents[$pid]['wards'][] = [
                    'id'                 => $row['s_id'],
                    'canonical_id'       => $row['canonical_student_id'],
                    'first_name'         => $row['s_first'],
                    'last_name'          => $row['s_last'],
                    'student_class'      => $row['student_class'],
                    'student_id_no'      => $row['student_id_no'],
                    'gender'             => $row['gender'],
                    'photo_path'         => $row['s_photo'],
                ];
            }
        }
        echo json_encode(['success' => true, 'data' => array_values($parents)]);
        break;

    // ── Attendance for an event ───────────────────────────────
    case 'attendance':
        $eventId = (int)($_GET['event_id'] ?? 0);
        if (!$eventId) { echo json_encode(['success' => false, 'message' => 'event_id required']); break; }

        $stmt = getDB()->prepare(
            'SELECT a.id, a.visit_type, a.signed_at, a.notes,
                    p.id AS parent_id, p.first_name, p.last_name, p.phone,
                    p.relationship, p.photo_path,
                    s.first_name AS s_first, s.last_name AS s_last, s.student_class
             FROM attendance a
             JOIN parents  p ON p.id = a.parent_id
             LEFT JOIN students s ON s.parent_id = p.id
             WHERE a.event_id = ?
             ORDER BY a.signed_at DESC'
        );
        $stmt->execute([$eventId]);
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        break;

    // ── Parent lookup by phone (for attendance & exeat) ───────
    case 'parent_by_phone':
        $phone = trim($_GET['phone'] ?? '');
        if (!$phone) { echo json_encode(['success' => false, 'message' => 'phone required']); break; }

        $stmt = getDB()->prepare(
            'SELECT p.id, p.first_name, p.last_name, p.phone, p.relationship, p.photo_path
             FROM parents p WHERE p.phone = ? LIMIT 1'
        );
        $stmt->execute([$phone]);
        $row = $stmt->fetch();
        if (!$row) { echo json_encode(['success' => false, 'message' => 'No parent found with that phone number.']); break; }

        // Fetch wards
        $ws = getDB()->prepare(
            'SELECT id, first_name, last_name, student_class, student_id_no, gender, photo_path
             FROM students WHERE parent_id = ? AND is_linked_copy = 0 ORDER BY first_name ASC'
        );
        $ws->execute([$row['id']]);
        $row['wards'] = $ws->fetchAll();
        // Also keep flat first ward fields for backwards compat
        $first = $row['wards'][0] ?? [];
        $row['s_first']       = $first['first_name'] ?? null;
        $row['s_last']        = $first['last_name']  ?? null;
        $row['student_class'] = $first['student_class'] ?? null;

        echo json_encode(['success' => true, 'data' => $row]);
        break;

    // ── Dashboard stats ───────────────────────────────────────
    case 'stats':
        $pdb = getDB();
        $totalParents  = (int)$pdb->query('SELECT COUNT(*) FROM parents')->fetchColumn();
        $totalStudents = (int)$pdb->query('SELECT COUNT(*) FROM students WHERE is_linked_copy = 0')->fetchColumn();
        $totalEvents   = (int)$pdb->query('SELECT COUNT(*) FROM events')->fetchColumn();
        $upcomingCount = (int)$pdb->query('SELECT COUNT(*) FROM events WHERE event_date >= CURDATE()')->fetchColumn();
        $pendingExeats = (int)$pdb->query("SELECT COUNT(*) FROM exeat_requests WHERE status = 'pending'")->fetchColumn();
        $offCampus     = (int)$pdb->query(
            "SELECT COUNT(*) FROM exeat_requests WHERE status = 'approved'
             AND departure_date <= CURDATE() AND (actual_return IS NULL OR actual_return > CURDATE())"
        )->fetchColumn();
        echo json_encode([
            'success' => true,
            'data' => compact('totalParents','totalStudents','totalEvents','upcomingCount','pendingExeats','offCampus')
        ]);
        break;

    // ── Search students by name or ID (for parent linking) ────
    case 'search_students':
        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) { echo json_encode(['success'=>true,'data'=>[]]); break; }

        $like = '%' . $q . '%';
        $stmt = getDB()->prepare(
            'SELECT s.id, s.first_name, s.last_name, s.student_class, s.student_id_no,
                    p.first_name AS p_first, p.last_name AS p_last, p.relationship
             FROM students s
             JOIN parents p ON p.id = s.parent_id
             WHERE s.is_linked_copy = 0
               AND (s.first_name LIKE ? OR s.last_name LIKE ?
                OR CONCAT(s.first_name," ",s.last_name) LIKE ?
                OR s.student_id_no LIKE ?)
             ORDER BY s.first_name ASC LIMIT 10'
        );
        $stmt->execute([$like, $like, $like, $like]);
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        break;

    // ── Exeat requests (filtered by status and/or gender) ─────
    case 'exeats':
        $status = trim($_GET['status'] ?? '');
        $gender = trim($_GET['gender'] ?? '');
        $allowed = ['pending','approved','declined'];

        $sql = 'SELECT e.id, e.reason, e.departure_date, e.departure_time, e.expected_return,
                       e.actual_return, e.status, e.review_note, e.created_at,
                       s.id AS student_id, s.first_name AS s_first, s.last_name AS s_last,
                       s.student_class, s.gender AS s_gender, s.student_id_no, s.photo_path AS s_photo,
                       p.id AS parent_id, p.first_name AS p_first, p.last_name AS p_last, p.phone AS p_phone,
                       a.full_name AS reviewer_name
                FROM exeat_requests e
                JOIN students s   ON s.id = e.student_id
                JOIN parents  p   ON p.id = e.parent_id
                LEFT JOIN admin_users a ON a.id = e.reviewed_by
                WHERE 1=1';
        $params = [];
        if ($status && in_array($status, $allowed, true)) {
            $sql .= ' AND e.status = ?'; $params[] = $status;
        }
        if ($gender) {
            $sql .= ' AND s.gender = ?'; $params[] = $gender;
        }
        $sql .= ' ORDER BY e.created_at DESC';

        $stmt = getDB()->prepare($sql);
        $stmt->execute($params);
        echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
        break;

    // ── Students filtered by gender (for house parents) ───────
    case 'students_by_gender':
        $gender = trim($_GET['gender'] ?? '');
        if (!$gender) { echo json_encode(['success'=>false,'message'=>'gender required']); break; }

        $stmt = getDB()->prepare(
            'SELECT s.id, s.first_name, s.last_name, s.student_class, s.student_id_no,
                    s.gender, s.photo_path,
                    p.first_name AS p_first, p.last_name AS p_last, p.phone AS p_phone,
                    (
                      SELECT COUNT(*) FROM exeat_requests ex
                      WHERE ex.student_id = s.id AND ex.status = \'approved\'
                        AND ex.departure_date <= CURDATE()
                        AND (ex.actual_return IS NULL OR ex.actual_return > CURDATE())
                    ) AS is_off_campus_count
             FROM students s
             JOIN parents p ON p.id = s.parent_id
             WHERE s.gender = ? AND s.is_linked_copy = 0
             ORDER BY s.first_name ASC'
        );
        $stmt->execute([$gender]);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            $r['on_campus'] = ((int)$r['is_off_campus_count'] === 0);
            unset($r['is_off_campus_count']);
        }
        unset($r);
        echo json_encode(['success' => true, 'data' => $rows]);
        break;

    // ── Full student record + exeat history ───────────────────
    case 'student_full_data':
        $sid = (int)($_GET['student_id'] ?? 0);
        if (!$sid) { echo json_encode(['success'=>false,'message'=>'student_id required']); break; }

        $pdb  = getDB();
        $stmt = $pdb->prepare(
            'SELECT s.id, s.first_name, s.last_name, s.student_class, s.student_id_no,
                    s.gender, s.date_of_birth, s.photo_path,
                    p.first_name AS p_first, p.last_name AS p_last,
                    p.phone, p.email, p.relationship
             FROM students s JOIN parents p ON p.id = s.parent_id
             WHERE s.id = ? LIMIT 1'
        );
        $stmt->execute([$sid]);
        $student = $stmt->fetch();
        if (!$student) { echo json_encode(['success'=>false,'message'=>'Student not found.']); break; }

        $ex = $pdb->prepare(
            'SELECT e.*, a.full_name AS reviewer_name
             FROM exeat_requests e
             LEFT JOIN admin_users a ON a.id = e.reviewed_by
             WHERE e.student_id = ? ORDER BY e.created_at DESC'
        );
        $ex->execute([$sid]);
        $exeats = $ex->fetchAll();

        echo json_encode(['success'=>true,'data'=>['student'=>$student,'exeats'=>$exeats]]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Unknown action.']);
}
