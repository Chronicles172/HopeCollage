-- ============================================================
-- SchoolConnect Migration v2  - Run if upgrading an EXISTING install
-- ============================================================

USE schoolconnect;

-- 1. Add role column to admin_users
ALTER TABLE admin_users
  ADD COLUMN IF NOT EXISTS role
    ENUM('admin','domestic_affairs','houseparent_male','houseparent_female')
    NOT NULL DEFAULT 'admin'
    AFTER email;

-- 2. Set existing admin to role='admin'
UPDATE admin_users SET role = 'admin' WHERE username = 'admin';

-- 3. Insert new staff accounts (skip if already present)
INSERT IGNORE INTO admin_users (username, password, full_name, email, role) VALUES
('domestic_affairs', '$2y$12$baOnF5GWjOWEXie0RRHjuuKoFfCQaYbx454ZQLHAdfLJcYld/glZy', 'Head of Domestic Affairs', 'domestic@schoolconnect.local', 'domestic_affairs'),
('houseparent_male', '$2y$12$1Mc7sby8Jj96WvdiyVK.cuXxRsjX1dBiB2c03NX0dfWw87DMgdYyS', 'Male House Parent', 'hp.male@schoolconnect.local', 'houseparent_male'),
('houseparent_female', '$2y$12$1Mc7sby8Jj96WvdiyVK.cuXxRsjX1dBiB2c03NX0dfWw87DMgdYyS', 'Female House Parent', 'hp.female@schoolconnect.local', 'houseparent_female');

-- 4. Add is_linked_copy if missing
ALTER TABLE students
  ADD COLUMN IF NOT EXISTS is_linked_copy TINYINT(1) NOT NULL DEFAULT 0;

-- 5b. Add source_student_id to track which original student a linked copy came from
ALTER TABLE students
  ADD COLUMN IF NOT EXISTS source_student_id INT NULL DEFAULT NULL;

-- 5. Create exeat_requests table
CREATE TABLE IF NOT EXISTS exeat_requests (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  student_id      INT NOT NULL,
  parent_id       INT NOT NULL,
  reason          TEXT NOT NULL,
  departure_date  DATE NOT NULL,
  departure_time  TIME NOT NULL,
  expected_return DATE NOT NULL,
  actual_return   DATE,
  status          ENUM('pending','approved','declined') NOT NULL DEFAULT 'pending',
  review_note     TEXT,
  reviewed_by     INT,
  reviewed_at     DATETIME,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_exeat_student  FOREIGN KEY (student_id)  REFERENCES students(id)  ON DELETE CASCADE,
  CONSTRAINT fk_exeat_parent   FOREIGN KEY (parent_id)   REFERENCES parents(id)   ON DELETE CASCADE,
  CONSTRAINT fk_exeat_reviewer FOREIGN KEY (reviewed_by) REFERENCES admin_users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
